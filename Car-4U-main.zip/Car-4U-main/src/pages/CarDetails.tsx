import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCarStore } from '@/store/carStore';
import { useBookingStore } from '@/store/bookingStore';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';

export default function CarDetails() {
  const { id } = useParams<{ id: string }>();
  const { selectedCar, fetchCarById, isLoading } = useCarStore();
  const { createBooking } = useBookingStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const [pickup, setPickup] = useState('');
  const [dropoff, setDropoff] = useState('');
  const [payment, setPayment] = useState<'cash' | 'online'>('cash');
  const [notes, setNotes] = useState('');
  const [booking, setBooking] = useState(false);
  const [activeImg, setActiveImg] = useState(0);

  useEffect(() => { if (id) fetchCarById(id); }, [id]);

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>جارٍ التحميل...</div>
    </div>
  );

  if (!selectedCar) return (
    <div className="min-h-screen flex items-center justify-center text-center px-4" style={{ fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}>
      <div>
        <div className="text-5xl mb-4">😕</div>
        <h2 className="text-xl font-bold text-white mb-4">السيارة غير موجودة</h2>
        <button onClick={() => navigate('/cars')} className="px-6 py-3 rounded-xl font-bold text-black" style={{ background: '#eab308' }}>العودة</button>
      </div>
    </div>
  );

  const car = selectedCar;
  const days = pickup && dropoff ? Math.max(1, Math.ceil((new Date(dropoff).getTime() - new Date(pickup).getTime()) / (1000 * 60 * 60 * 24))) : 0;
  const total = days * car.daily_price;

  const handleBook = async () => {
    if (!user) { toast.error('يجب تسجيل الدخول أولاً'); navigate('/login'); return; }
    if (!pickup || !dropoff) { toast.error('يرجى تحديد تواريخ الاستلام والتسليم'); return; }
    if (new Date(dropoff) <= new Date(pickup)) { toast.error('تاريخ التسليم يجب أن يكون بعد تاريخ الاستلام'); return; }
    setBooking(true);
    try {
      await createBooking({
        user_id: user.id, user_name: user.full_name, user_phone: user.phone,
        car_id: car.id, pickup_date: pickup, dropoff_date: dropoff,
        total_price: total, payment_method: payment, status: 'pending', notes,
      });
      toast.success('تم إرسال طلب الحجز بنجاح! سيتم التأكيد قريباً');
      navigate('/dashboard');
    } finally { setBooking(false); }
  };

  const inp = "w-full px-3 py-2.5 rounded-xl text-white text-sm outline-none";
  const inpS = { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' };

  return (
    <div className="min-h-screen py-20 px-4" style={{ fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}>
      <div className="max-w-6xl mx-auto">
        <button onClick={() => navigate(-1)} className="mb-6 text-sm flex items-center gap-2" style={{ color: 'rgba(255,255,255,0.5)' }}>
          → العودة
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* LEFT: Car Info */}
          <div className="lg:col-span-2">
            {/* Images */}
            <div className="rounded-2xl overflow-hidden mb-4" style={{ height: '360px' }}>
              <img src={car.images[activeImg] || car.images[0]} alt="" className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800'; }} />
            </div>
            {car.images.length > 1 && (
              <div className="flex gap-3 mb-6">
                {car.images.map((img, i) => (
                  <button key={i} onClick={() => setActiveImg(i)} className="w-20 h-16 rounded-xl overflow-hidden flex-shrink-0 transition-all" style={{ opacity: activeImg === i ? 1 : 0.5, border: activeImg === i ? '2px solid #eab308' : '2px solid transparent' }}>
                    <img src={img} className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=100'; }} />
                  </button>
                ))}
              </div>
            )}

            {/* Car Info */}
            <div className="mb-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h1 className="text-3xl font-black text-white mb-1">{car.brand} {car.model}</h1>
                  <p style={{ color: 'rgba(255,255,255,0.5)' }}>{car.year} · {car.color} · {car.location || 'القاهرة'}</p>
                </div>
                <div className="text-left">
                  <div className="text-3xl font-black" style={{ color: '#eab308' }}>{car.daily_price}</div>
                  <div className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>ج.م / يوم</div>
                </div>
              </div>
              {car.owner_id && (
                <div className="flex items-center gap-2 px-4 py-3 rounded-xl mb-4" style={{ background: 'rgba(96,165,250,0.08)', border: '1px solid rgba(96,165,250,0.2)' }}>
                  <span className="text-blue-400">👤</span>
                  <span className="text-sm" style={{ color: '#93c5fd' }}>سيارة مالك خاص — {car.owner_name}</span>
                </div>
              )}
              {car.description && <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.6)' }}>{car.description}</p>}
            </div>

            {/* Specs Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { icon: '💺', label: 'المقاعد', val: car.specifications.seats },
                { icon: '⚙️', label: 'الناقل', val: car.specifications.transmission },
                { icon: '⛽', label: 'الوقود', val: car.specifications.fuel_type },
                { icon: '🔧', label: 'المحرك', val: car.specifications.engine },
                { icon: '📍', label: 'الموقع', val: car.location },
                { icon: '📅', label: 'السنة', val: car.year },
              ].filter(s => s.val).map(spec => (
                <div key={spec.label} className="rounded-xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                  <div className="text-xl mb-1">{spec.icon}</div>
                  <div className="text-xs mb-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>{spec.label}</div>
                  <div className="text-sm font-semibold text-white">{spec.val}</div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT: Booking Form */}
          <div>
            <div className="rounded-2xl p-6 sticky top-20" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(234,179,8,0.2)' }}>
              <h2 className="text-xl font-bold text-white mb-5">احجز الآن</h2>

              <div className="space-y-4 mb-5">
                <div>
                  <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>تاريخ الاستلام</label>
                  <input type="date" className={inp} style={inpS} value={pickup} min={new Date().toISOString().split('T')[0]} onChange={e => setPickup(e.target.value)} />
                </div>
                <div>
                  <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>تاريخ التسليم</label>
                  <input type="date" className={inp} style={inpS} value={dropoff} min={pickup || new Date().toISOString().split('T')[0]} onChange={e => setDropoff(e.target.value)} />
                </div>

                <div>
                  <label className="text-xs mb-2 block" style={{ color: 'rgba(255,255,255,0.5)' }}>طريقة الدفع</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[{ v: 'cash' as const, l: '💵 كاش' }, { v: 'online' as const, l: '💳 أونلاين' }].map(p => (
                      <button key={p.v} onClick={() => setPayment(p.v)} className="py-2.5 rounded-xl text-sm transition-all" style={{ background: payment === p.v ? 'rgba(234,179,8,0.15)' : 'rgba(255,255,255,0.04)', color: payment === p.v ? '#eab308' : 'rgba(255,255,255,0.5)', border: payment === p.v ? '1px solid rgba(234,179,8,0.4)' : '1px solid rgba(255,255,255,0.08)' }}>
                        {p.l}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>ملاحظات (اختياري)</label>
                  <textarea className={inp} style={{ ...inpS, minHeight: '60px', resize: 'none' }} placeholder="أي طلبات خاصة..." value={notes} onChange={e => setNotes(e.target.value)} />
                </div>
              </div>

              {/* Price Summary */}
              {days > 0 && (
                <div className="rounded-xl p-4 mb-4" style={{ background: 'rgba(234,179,8,0.06)', border: '1px solid rgba(234,179,8,0.15)' }}>
                  <div className="flex justify-between text-sm mb-2">
                    <span style={{ color: 'rgba(255,255,255,0.5)' }}>{car.daily_price} ج × {days} يوم</span>
                    <span className="text-white">{total} ج</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span style={{ color: '#eab308' }}>الإجمالي</span>
                    <span style={{ color: '#eab308', fontSize: '1.1rem' }}>{total} ج.م</span>
                  </div>
                </div>
              )}

              <button onClick={handleBook} disabled={booking || !car.is_available} className="w-full py-3.5 rounded-xl font-bold text-black text-sm disabled:opacity-50 transition-all hover:opacity-90" style={{ background: car.is_available ? 'linear-gradient(135deg, #eab308, #f59e0b)' : 'rgba(255,255,255,0.1)', color: car.is_available ? '#000' : 'rgba(255,255,255,0.3)', fontFamily: 'Cairo, sans-serif' }}>
                {!car.is_available ? 'غير متاحة للحجز' : booking ? 'جارٍ الإرسال...' : 'تأكيد الحجز'}
              </button>

              {!user && (
                <p className="text-center text-xs mt-3" style={{ color: 'rgba(255,255,255,0.4)' }}>
                  يجب <span style={{ color: '#eab308' }}>تسجيل الدخول</span> للحجز
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
