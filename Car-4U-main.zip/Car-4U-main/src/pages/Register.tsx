import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';

export default function Register() {
  const { signUp, isLoading } = useAuthStore();
  const navigate = useNavigate();
  const [role, setRole] = useState<'user' | 'owner'>('user');
  const [form, setForm] = useState({ email: '', password: '', full_name: '', phone: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password || !form.full_name) { toast.error('يرجى تعبئة جميع الحقول'); return; }
    await signUp(form.email, form.password, form.full_name, form.phone, role);
    toast.success('تم إنشاء الحساب بنجاح!');
    navigate(role === 'owner' ? '/list-car' : '/cars');
  };

  const inp = "w-full px-4 py-3 rounded-xl text-white text-sm outline-none transition-all";
  const inpStyle = { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' };
  const inpFocus = { borderColor: 'rgba(234,179,8,0.5)' };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-20" style={{ fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}>
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex text-4xl mb-4">🚗</div>
          <h1 className="text-3xl font-black text-white mb-2">إنشاء حساب جديد</h1>
          <p style={{ color: 'rgba(255,255,255,0.5)' }}>لديك حساب؟ <Link to="/login" style={{ color: '#eab308', textDecoration: 'none' }}>سجّل دخول</Link></p>
        </div>

        <div className="rounded-2xl p-8" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
          {/* Role Selector */}
          <div className="mb-6">
            <p className="text-sm font-semibold text-white mb-3">أنا أريد:</p>
            <div className="grid grid-cols-2 gap-3">
              <button type="button" onClick={() => setRole('user')} className="p-4 rounded-xl text-center transition-all" style={{ background: role === 'user' ? 'rgba(234,179,8,0.15)' : 'rgba(255,255,255,0.03)', border: role === 'user' ? '1px solid rgba(234,179,8,0.5)' : '1px solid rgba(255,255,255,0.08)', color: role === 'user' ? '#eab308' : 'rgba(255,255,255,0.5)' }}>
                <div className="text-2xl mb-1">🚗</div>
                <div className="text-sm font-semibold">استئجار سيارة</div>
              </button>
              <button type="button" onClick={() => setRole('owner')} className="p-4 rounded-xl text-center transition-all" style={{ background: role === 'owner' ? 'rgba(34,197,94,0.12)' : 'rgba(255,255,255,0.03)', border: role === 'owner' ? '1px solid rgba(34,197,94,0.4)' : '1px solid rgba(255,255,255,0.08)', color: role === 'owner' ? '#22c55e' : 'rgba(255,255,255,0.5)' }}>
                <div className="text-2xl mb-1">💰</div>
                <div className="text-sm font-semibold">تأجير سيارتي</div>
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.7)' }}>الاسم الكامل</label>
              <input className={inp} style={inpStyle} placeholder="اسمك الكامل" value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} onFocus={e => Object.assign(e.target.style, inpFocus)} onBlur={e => Object.assign(e.target.style, inpStyle)} />
            </div>
            <div>
              <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.7)' }}>البريد الإلكتروني</label>
              <input type="email" className={inp} style={inpStyle} placeholder="example@email.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} onFocus={e => Object.assign(e.target.style, inpFocus)} onBlur={e => Object.assign(e.target.style, inpStyle)} />
            </div>
            <div>
              <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.7)' }}>رقم الهاتف</label>
              <input className={inp} style={inpStyle} placeholder="01xxxxxxxxx" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} onFocus={e => Object.assign(e.target.style, inpFocus)} onBlur={e => Object.assign(e.target.style, inpStyle)} />
            </div>
            <div>
              <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.7)' }}>كلمة المرور</label>
              <input type="password" className={inp} style={inpStyle} placeholder="••••••••" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} onFocus={e => Object.assign(e.target.style, inpFocus)} onBlur={e => Object.assign(e.target.style, inpStyle)} />
            </div>
            <button type="submit" disabled={isLoading} className="w-full py-3 rounded-xl font-bold text-black transition-all hover:opacity-90 disabled:opacity-50 mt-2" style={{ background: role === 'owner' ? 'linear-gradient(135deg, #22c55e, #16a34a)' : 'linear-gradient(135deg, #eab308, #f59e0b)', fontFamily: 'Cairo, sans-serif' }}>
              {isLoading ? 'جارٍ التسجيل...' : role === 'owner' ? 'إنشاء حساب مالك' : 'إنشاء الحساب'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
