import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { useCarStore } from '@/store/carStore';
import { toast } from 'sonner';

export default function ListCar() {
  const { user } = useAuthStore();
  const { createCar } = useCarStore();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const [form, setForm] = useState({
    brand: '', model: '', year: new Date().getFullYear(), color: '',
    daily_price: '', location: '', description: '',
    seats: '', transmission: 'أوتوماتيك', fuel_type: 'بنزين', engine: '',
    images: ['', '', ''],
  });

  const setF = (k: string, v: any) => setForm(prev => ({ ...prev, [k]: v }));
  const setImg = (i: number, v: string) => {
    const imgs = [...form.images]; imgs[i] = v;
    setForm(prev => ({ ...prev, images: imgs }));
  };

  const handleSubmit = async () => {
    if (!form.brand || !form.model || !form.daily_price) { toast.error('يرجى تعبئة الحقول المطلوبة'); return; }
    if (!user) { toast.error('يجب تسجيل الدخول أولاً'); navigate('/login'); return; }
    setIsLoading(true);
    try {
      const validImages = form.images.filter(img => img.trim());
      await createCar({
        brand: form.brand, model: form.model, year: Number(form.year), color: form.color,
        daily_price: Number(form.daily_price), location: form.location, description: form.description,
        images: validImages.length ? validImages : ['https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800'],
        specifications: { seats: Number(form.seats), transmission: form.transmission, fuel_type: form.fuel_type, engine: form.engine },
        is_available: true,
        listing_status: 'pending',
        owner_id: user.id,
        owner_name: user.full_name,
        owner_phone: user.phone,
      });
      toast.success('تم إرسال طلب الإضافة بنجاح! سيتم مراجعته خلال 24 ساعة');
      navigate(user.role === 'owner' ? '/my-listings' : '/');
    } finally { setIsLoading(false); }
  };

  const inp = "w-full px-4 py-3 rounded-xl text-white text-sm outline-none";
  const inpS = { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center text-center px-4" style={{ fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}>
        <div>
          <div className="text-6xl mb-6">🔐</div>
          <h2 className="text-2xl font-bold text-white mb-4">يجب تسجيل الدخول أولاً</h2>
          <p className="mb-6" style={{ color: 'rgba(255,255,255,0.5)' }}>سجّل حساباً كمالك سيارة لتتمكن من إضافة سيارتك</p>
          <div className="flex gap-3 justify-center">
            <Link to="/register" className="px-6 py-3 rounded-xl font-bold text-black" style={{ background: '#eab308', textDecoration: 'none' }}>إنشاء حساب</Link>
            <Link to="/login" className="px-6 py-3 rounded-xl font-bold" style={{ border: '1px solid rgba(234,179,8,0.3)', color: '#eab308', textDecoration: 'none' }}>تسجيل الدخول</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-20 px-4" style={{ fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}>
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-black text-white mb-2">أجّر سيارتك عبر Car 4U</h1>
          <p style={{ color: 'rgba(255,255,255,0.5)' }}>أضف تفاصيل سيارتك وسنتولى الاعتماد والنشر</p>
        </div>

        {/* Steps */}
        <div className="flex items-center gap-2 mb-10 justify-center">
          {[1, 2, 3].map(s => (
            <div key={s} className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all" style={{ background: step >= s ? '#eab308' : 'rgba(255,255,255,0.1)', color: step >= s ? '#000' : 'rgba(255,255,255,0.4)' }}>{s}</div>
              {s < 3 && <div className="w-12 h-px" style={{ background: step > s ? '#eab308' : 'rgba(255,255,255,0.1)' }}></div>}
            </div>
          ))}
        </div>

        <div className="rounded-2xl p-8" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
          {/* STEP 1: Basic Info */}
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-white mb-6">بيانات السيارة الأساسية</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>الماركة *</label>
                  <input className={inp} style={inpS} placeholder="مثال: تويوتا" value={form.brand} onChange={e => setF('brand', e.target.value)} />
                </div>
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>الموديل *</label>
                  <input className={inp} style={inpS} placeholder="مثال: كامري" value={form.model} onChange={e => setF('model', e.target.value)} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>سنة الصنع *</label>
                  <input type="number" className={inp} style={inpS} value={form.year} onChange={e => setF('year', e.target.value)} />
                </div>
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>اللون</label>
                  <input className={inp} style={inpS} placeholder="أبيض" value={form.color} onChange={e => setF('color', e.target.value)} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>السعر اليومي (ج.م) *</label>
                  <input type="number" className={inp} style={inpS} placeholder="250" value={form.daily_price} onChange={e => setF('daily_price', e.target.value)} />
                </div>
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>الموقع</label>
                  <input className={inp} style={inpS} placeholder="القاهرة" value={form.location} onChange={e => setF('location', e.target.value)} />
                </div>
              </div>
              <div>
                <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>وصف السيارة</label>
                <textarea className={inp} style={{ ...inpS, minHeight: '80px', resize: 'vertical' }} placeholder="اكتب وصفاً مختصراً للسيارة..." value={form.description} onChange={e => setF('description', e.target.value)} />
              </div>
            </div>
          )}

          {/* STEP 2: Specs */}
          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-white mb-6">المواصفات التقنية</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>عدد المقاعد</label>
                  <input type="number" className={inp} style={inpS} placeholder="5" value={form.seats} onChange={e => setF('seats', e.target.value)} />
                </div>
                <div>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>المحرك</label>
                  <input className={inp} style={inpS} placeholder="2.5L" value={form.engine} onChange={e => setF('engine', e.target.value)} />
                </div>
              </div>
              <div>
                <label className="text-sm mb-2 block" style={{ color: 'rgba(255,255,255,0.6)' }}>ناقل الحركة</label>
                <div className="grid grid-cols-2 gap-3">
                  {['أوتوماتيك', 'يدوي'].map(t => (
                    <button key={t} type="button" onClick={() => setF('transmission', t)} className="py-3 rounded-xl text-sm font-semibold transition-all" style={{ background: form.transmission === t ? 'rgba(234,179,8,0.15)' : 'rgba(255,255,255,0.03)', border: form.transmission === t ? '1px solid rgba(234,179,8,0.5)' : '1px solid rgba(255,255,255,0.08)', color: form.transmission === t ? '#eab308' : 'rgba(255,255,255,0.5)' }}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm mb-2 block" style={{ color: 'rgba(255,255,255,0.6)' }}>نوع الوقود</label>
                <div className="grid grid-cols-3 gap-3">
                  {['بنزين', 'ديزل', 'هجين'].map(f => (
                    <button key={f} type="button" onClick={() => setF('fuel_type', f)} className="py-3 rounded-xl text-sm font-semibold transition-all" style={{ background: form.fuel_type === f ? 'rgba(234,179,8,0.15)' : 'rgba(255,255,255,0.03)', border: form.fuel_type === f ? '1px solid rgba(234,179,8,0.5)' : '1px solid rgba(255,255,255,0.08)', color: form.fuel_type === f ? '#eab308' : 'rgba(255,255,255,0.5)' }}>
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Images */}
          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-white mb-2">صور السيارة</h2>
              <p className="text-sm mb-6" style={{ color: 'rgba(255,255,255,0.4)' }}>أضف روابط صور السيارة (سيقوم الأدمن بمراجعتها وإمكانية تعديلها)</p>
              {form.images.map((img, i) => (
                <div key={i}>
                  <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.6)' }}>رابط الصورة {i + 1} {i === 0 ? '*' : '(اختياري)'}</label>
                  <input className={inp} style={inpS} placeholder="https://..." value={img} onChange={e => setImg(i, e.target.value)} />
                  {img && (
                    <div className="mt-2 h-32 rounded-lg overflow-hidden">
                      <img src={img} alt="preview" className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                    </div>
                  )}
                </div>
              ))}
              <div className="rounded-xl p-4 mt-4" style={{ background: 'rgba(234,179,8,0.06)', border: '1px solid rgba(234,179,8,0.15)' }}>
                <p className="text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
                  <span style={{ color: '#eab308' }}>ملاحظة: </span>
                  سيقوم فريق Car 4U بمراجعة إعلانك وإمكانية إضافة صور احترافية إذا لزم الأمر.
                </p>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <button onClick={() => setStep(s => s - 1)} disabled={step === 1} className="px-6 py-3 rounded-xl text-sm font-semibold transition-all disabled:opacity-30" style={{ border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>
              ← السابق
            </button>
            {step < 3 ? (
              <button onClick={() => setStep(s => s + 1)} className="px-6 py-3 rounded-xl text-sm font-bold text-black transition-all hover:opacity-90" style={{ background: 'linear-gradient(135deg, #eab308, #f59e0b)', fontFamily: 'Cairo, sans-serif' }}>
                التالي →
              </button>
            ) : (
              <button onClick={handleSubmit} disabled={isLoading} className="px-8 py-3 rounded-xl text-sm font-bold text-black transition-all hover:opacity-90 disabled:opacity-50" style={{ background: 'linear-gradient(135deg, #22c55e, #16a34a)', fontFamily: 'Cairo, sans-serif' }}>
                {isLoading ? 'جارٍ الإرسال...' : 'إرسال للمراجعة ✓'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
