import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';

export default function Login() {
  const { signIn, isLoading } = useAuthStore();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password) { toast.error('يرجى تعبئة جميع الحقول'); return; }
    await signIn(form.email, form.password);
    toast.success('تم تسجيل الدخول بنجاح!');
    navigate('/');
  };

  const inp = "w-full px-4 py-3 rounded-xl text-white text-sm outline-none";
  const inpS = { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-20" style={{ fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}>
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-4xl mb-4">🔑</div>
          <h1 className="text-3xl font-black text-white mb-2">تسجيل الدخول</h1>
          <p style={{ color: 'rgba(255,255,255,0.5)' }}>ليس لديك حساب؟ <Link to="/register" style={{ color: '#eab308', textDecoration: 'none' }}>سجّل الآن</Link></p>
        </div>

        <div className="rounded-2xl p-8" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
          

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.7)' }}>البريد الإلكتروني</label>
              <input type="email" className={inp} style={inpS} placeholder="example@email.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label className="text-sm mb-1 block" style={{ color: 'rgba(255,255,255,0.7)' }}>كلمة المرور</label>
              <input type="password" className={inp} style={inpS} placeholder="••••••••" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
            </div>
            <button type="submit" disabled={isLoading} className="w-full py-3 rounded-xl font-bold text-black mt-2 disabled:opacity-50 hover:opacity-90 transition-all" style={{ background: 'linear-gradient(135deg, #eab308, #f59e0b)', fontFamily: 'Cairo, sans-serif' }}>
              {isLoading ? 'جارٍ الدخول...' : 'تسجيل الدخول'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
