import { create } from 'zustand';
import type { Car, CarFilter } from '@/types';
import { mockSupabaseService } from '@/lib/supabase';

interface CarState {
  cars: Car[];
  allCars: Car[];
  selectedCar: Car | null;
  isLoading: boolean;
  error: string | null;
  filters: CarFilter;
  fetchCars: (filters?: CarFilter) => Promise<void>;
  fetchAllCarsAdmin: () => Promise<void>;
  fetchOwnerCars: (ownerId: string) => Promise<void>;
  fetchCarById: (id: string) => Promise<void>;
  createCar: (car: Omit<Car, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateCar: (id: string, updates: Partial<Car>) => Promise<void>;
  deleteCar: (id: string) => Promise<void>;
  approveListing: (id: string) => Promise<void>;
  rejectListing: (id: string, reason: string) => Promise<void>;
  setFilters: (filters: CarFilter) => void;
  clearSelectedCar: () => void;
  clearError: () => void;
}

export const useCarStore = create<CarState>((set, get) => ({
  cars: [],
  allCars: [],
  selectedCar: null,
  isLoading: false,
  error: null,
  filters: {},

  fetchCars: async (filters) => {
    set({ isLoading: true, error: null });
    try {
      const cars = await mockSupabaseService.getCars(filters);
      set({ cars, isLoading: false });
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  fetchAllCarsAdmin: async () => {
    set({ isLoading: true, error: null });
    try {
      const allCars = await mockSupabaseService.getAllCarsAdmin();
      set({ allCars, isLoading: false });
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  fetchOwnerCars: async (ownerId) => {
    set({ isLoading: true, error: null });
    try {
      const cars = await mockSupabaseService.getOwnerCars(ownerId);
      set({ cars, isLoading: false });
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  fetchCarById: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const car = await mockSupabaseService.getCarById(id);
      set({ selectedCar: car, isLoading: false });
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  createCar: async (car) => {
    set({ isLoading: true, error: null });
    try {
      const newCar = await mockSupabaseService.createCar(car);
      set((state) => ({ allCars: [...state.allCars, newCar], cars: car.listing_status === 'approved' ? [...state.cars, newCar] : state.cars, isLoading: false }));
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  updateCar: async (id, updates) => {
    set({ isLoading: true, error: null });
    try {
      const updatedCar = await mockSupabaseService.updateCar(id, updates);
      if (updatedCar) {
        set((state) => ({
          allCars: state.allCars.map(c => c.id === id ? updatedCar : c),
          cars: state.cars.map(c => c.id === id ? updatedCar : c),
          selectedCar: state.selectedCar?.id === id ? updatedCar : state.selectedCar,
          isLoading: false,
        }));
      }
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  deleteCar: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await mockSupabaseService.deleteCar(id);
      set((state) => ({
        allCars: state.allCars.filter(c => c.id !== id),
        cars: state.cars.filter(c => c.id !== id),
        isLoading: false,
      }));
    } catch (err: any) {
      set({ error: err.message, isLoading: false });
    }
  },

  approveListing: async (id) => {
    const car = await mockSupabaseService.approveListing(id);
    if (car) set((state) => ({ allCars: state.allCars.map(c => c.id === id ? car : c) }));
  },

  rejectListing: async (id, reason) => {
    const car = await mockSupabaseService.rejectListing(id, reason);
    if (car) set((state) => ({ allCars: state.allCars.map(c => c.id === id ? car : c) }));
  },

  setFilters: (filters) => { set({ filters }); get().fetchCars(filters); },
  clearSelectedCar: () => set({ selectedCar: null }),
  clearError: () => set({ error: null }),
}));
