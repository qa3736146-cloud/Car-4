import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '@/types';
import { mockSupabaseService } from '@/lib/supabase';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  signUp: (email: string, password: string, fullName: string, phone: string, role?: User['role']) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  setUser: (user: User | null) => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: mockSupabaseService.getCurrentUser(),
      isLoading: false,
      error: null,

      signUp: async (email, password, fullName, phone, role = 'user') => {
        set({ isLoading: true, error: null });
        try {
          const { data, error } = await mockSupabaseService.signUp(email, password, fullName, phone, role);
          if (error) throw error;
          set({ user: data.user, isLoading: false });
        } catch (err: any) {
          set({ error: err.message || 'حدث خطأ أثناء التسجيل', isLoading: false });
        }
      },

      signIn: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          const { data, error } = await mockSupabaseService.signIn(email, password);
          if (error) throw error;
          set({ user: data.user, isLoading: false });
        } catch (err: any) {
          set({ error: err.message || 'حدث خطأ أثناء تسجيل الدخول', isLoading: false });
        }
      },

      signOut: async () => {
        set({ isLoading: true });
        await mockSupabaseService.signOut();
        set({ user: null, isLoading: false });
      },

      setUser: (user) => set({ user }),
      clearError: () => set({ error: null }),
    }),
    { name: 'auth-storage', partialize: (state) => ({ user: state.user }) }
  )
);
