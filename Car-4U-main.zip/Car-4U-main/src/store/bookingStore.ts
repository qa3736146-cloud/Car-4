import { create } from 'zustand';
import type { Booking } from '@/types';
import { mockSupabaseService } from '@/lib/supabase';

interface BookingState {
  bookings: Booking[];
  userBookings: Booking[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchAllBookings: () => Promise<void>;
  fetchUserBookings: (userId: string) => Promise<void>;
  createBooking: (booking: Omit<Booking, 'id' | 'created_at'>) => Promise<void>;
  updateBookingStatus: (id: string, status: Booking['status']) => Promise<void>;
  clearError: () => void;
}

export const useBookingStore = create<BookingState>((set) => ({
  bookings: [],
  userBookings: [],
  isLoading: false,
  error: null,

  fetchAllBookings: async () => {
    set({ isLoading: true, error: null });
    try {
      const bookings = await mockSupabaseService.getBookings();
      set({ bookings, isLoading: false });
    } catch (err: any) {
      set({ error: err.message || 'حدث خطأ أثناء جلب الحجوزات', isLoading: false });
    }
  },

  fetchUserBookings: async (userId) => {
    set({ isLoading: true, error: null });
    try {
      const bookings = await mockSupabaseService.getBookings(userId);
      set({ userBookings: bookings, isLoading: false });
    } catch (err: any) {
      set({ error: err.message || 'حدث خطأ أثناء جلب حجوزاتك', isLoading: false });
    }
  },

  createBooking: async (booking) => {
    set({ isLoading: true, error: null });
    try {
      const newBooking = await mockSupabaseService.createBooking(booking);
      set((state) => ({
        bookings: [...state.bookings, newBooking],
        userBookings: booking.user_id === newBooking.user_id 
          ? [...state.userBookings, newBooking] 
          : state.userBookings,
        isLoading: false,
      }));
    } catch (err: any) {
      set({ error: err.message || 'حدث خطأ أثناء إنشاء الحجز', isLoading: false });
    }
  },

  updateBookingStatus: async (id, status) => {
    set({ isLoading: true, error: null });
    try {
      const updatedBooking = await mockSupabaseService.updateBookingStatus(id, status);
      if (updatedBooking) {
        set((state) => ({
          bookings: state.bookings.map((b) => (b.id === id ? updatedBooking : b)),
          userBookings: state.userBookings.map((b) => (b.id === id ? updatedBooking : b)),
          isLoading: false,
        }));
      }
    } catch (err: any) {
      set({ error: err.message || 'حدث خطأ أثناء تحديث حالة الحجز', isLoading: false });
    }
  },

  clearError: () => set({ error: null }),
}));
